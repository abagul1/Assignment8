package cs3500.animator.view.visualview;

/**
 * Represents the window to be displayed based on which Jbutton is clicked.
 */
public enum WindowType {
  ANIMATION, SHAPEMENU
}
