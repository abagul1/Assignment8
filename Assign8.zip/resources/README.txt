Assignment 8

    The provider views offer the full functionality of the editor, with the exception of saving
    and loading files. Our adapters were able to convert our animation model to represent
    the provider's animation model, thus allowing for the inserting, deleting, and modification of
    key frames, as well as the creation and deletion of shapes.

    The provider view also provides the basic playback controls such as pause, play, restart,
    loop, increase speed, and decrease speed.

    the existing editor, visual, svg, and text view from our previous assignment are still fully
    functional and the user can call them by inputting the appropriate tag.
